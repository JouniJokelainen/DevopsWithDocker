const request = require('request');
const urlAlku = 'https://fi.wikipedia.org/w/api.php?action=query&prop=extracts&titles=';
const urlLoppu = '&exintro=&exsentences=2&explaintext=&redirects=&formatversion=2&format=json';

let hakusana = "";
for (let i=2; i < process.argv.length; i++) {
    hakusana += process.argv[i];
    if (i < process.argv.length - 1) {
        hakusana += "_";
    }
}

const url = urlAlku + hakusana + urlLoppu

function wiki(url) {
    request({uri: url, json: true}, (error, response, body) => {
        if (error) {
            console.log("Yhteysongelmia");
        } else if (body.error) {
            console.log("Ruumisvirhe");
        } else {
            console.log(body.query.pages[0].extract);
        }
    });
}

wiki(url);